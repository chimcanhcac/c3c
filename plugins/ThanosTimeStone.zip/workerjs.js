var fs = require("fs");
var path = require("path");
const worker = require('worker_threads');
var Worker = worker.Worker;
var parentPort = worker.parentPort;
var os = require("os");

var dirname = worker.workerData.dirname;
var modelport = worker.workerData.port;
var workerID = worker.workerData.i;
var isSmall = worker.workerData.small;

var nsfwjs = require(path.join(dirname, "..", "node_modules", "nsfwjs"));
var resolvedModel = null;

parentPort.postMessage({
	busy: true,
	i: workerID,
	resolve: false
});

nsfwjs
	.load(`http://127.0.0.1:${modelport}/nsfwjs-models${isSmall ? "-small" : ""}`, {
		size: (isSmall ? 224 : 299)
	})
	.then(m => {
		resolvedModel = m;
		parentPort.postMessage({
			busy: false,
			i: workerID,
			resolve: false
		});
	})
	.catch(ex => {
		nsfwjs
			.load(`https://lequanglam.github.io/nsfwjs-model/`, {
				size: 299
			})
			.then(m => {
				resolvedModel = m;
				parentPort.postMessage({
					busy: false,
					i: workerID,
					resolve: false
				});
			});
	});
	
parentPort.on('message', (msg) => {
	parentPort.postMessage({
		busy: true,
		i: workerID,
		resolve: false
	});
	resolvedModel.classify({
		data: new Uint8Array(msg.data),
		width: msg.width,
		height: msg.height
	}, 5).then(c => {
		parentPort.postMessage({
			busy: false,
			i: workerID,
			resolve: true,
			data: c,
			msgID: msg.id
		});
	});
});